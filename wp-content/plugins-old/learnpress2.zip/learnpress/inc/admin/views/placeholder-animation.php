<?php
/**
 * Template for displaying a placeholder with animation effect.
 *
 * @author  ThimPress
 * @package LearnPress/Admin/Views
 * @version 3.0.7
 */

defined( 'ABSPATH' ) or die();
?>
<div class="line-heading"></div>

<div class="line-sm"></div>
<div class="line-xs"></div>

<div class="line-df"></div>
<div class="line-lgx"></div>
<div class="line-lg"></div>

<div class="line-df"></div>
<div class="line-lg"></div>
<div class="line-lgx"></div>
