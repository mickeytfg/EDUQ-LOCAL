;(function ($) {
    $(document).ready(function () {
        $('.learn-press-tip').QuickTip();
    })
})(jQuery);